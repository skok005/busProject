package chatbots;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.server.ServerEndpoint;


@ServerEndpoint("/webChat1")
public class webChat1 {
	
	@OnOpen
	public void handleOpen() {
		System.out.println("Ŭ���̾�Ʈ ����");
	}
	
	@OnClose
	public void handleClose() {
		System.out.println("Ŭ���̾�Ʈ ����");
	}
	
	@OnError
	public void handleError(Throwable t) {
		System.out.println("chatbos error : " + t);
	}
	
	@OnMessage
	public String handleMessage(String msg) {
		System.out.println("clientMsg => " + msg);
		msg = msg.replaceAll("(\r\n|\r|\n|\n\r)", " ");
		String rmsg = "echo " + msg;
		if(rmsg!="") {
			System.out.println("serverMsg => " + rmsg);
			return rmsg;
		}
		return "";
	}
	
}
